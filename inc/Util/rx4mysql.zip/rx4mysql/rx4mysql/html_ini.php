<!DOCTYPE html>
<html>
    <head>
        <title>The Web Coffee Machine rx4</title>
        <link href="estilos.css" media="screen" rel="stylesheet" type="text/css" />
        
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>
    <body>
        <div class="titulo"> <h1>The Web Coffee Machine 4 Mysql Databases</h1></div>
        
        <div class="content">