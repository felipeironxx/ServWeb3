<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Recuperar Senha</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<form name="senha" method="post" action="enviar_senha.php">
  <table width="400" border="0" cellspacing="0" cellpadding="0">
    <tr> 
      <td width="150"><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Login:</font></td>
      <td width="250"><input name="login" type="text" id="login"></td>
    </tr>
    <tr> 
      <td><font size="2" face="Verdana, Arial, Helvetica, sans-serif">Email:</font></td>
      <td><input name="email" type="text" id="email"></td>
    </tr>
    <tr> 
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr> 
      <td colspan="2"><div align="center"> 
          <input name="enviar" type="submit" id="enviar" value="Enviar minha Senha">
        </div></td>
    </tr>
  </table>
</form>
</body>
</html>
