<?
$host		=	"127.0.0.1"; //endere�o do seu servidor MySQL
$database	=	"dbsevweb"; //o database que conter� sua tabela, muitas vezes seu pr�prio login
$tabela		=	"usuario"; //o nome de sua tabela
$login_db	=	"root"; //login usado no MySQL
$senha_db	=	"root"; //senha usado no MySQL
?>
